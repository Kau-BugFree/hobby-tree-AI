import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from app.api import router
from app.config import DataBundle
from app.service import RecommendationService


def create_app(data_directory: Path | None = None) -> FastAPI:
    directory = data_directory or Path(os.environ.get("RECOMMENDER_DATA_DIR", str(Path(__file__).parent / "data")))

    @asynccontextmanager
    async def lifespan(application):
        application.state.recommender = RecommendationService(DataBundle(directory))
        yield

    application = FastAPI(
        title="HobbyTree Recommendation API", version="1.0.0",
        description="온보딩 답변에 따른 설명 가능한 규칙 기반 추천. 점수는 확률이 아닙니다.",
        lifespan=lifespan,
    )
    origins = [o.strip() for o in os.environ.get("CORS_ORIGINS", "http://localhost:8081,http://localhost:19006").split(",") if o.strip()]
    application.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False,
                               allow_methods=["GET", "POST"], allow_headers=["Content-Type", "Authorization"])
    application.include_router(router)

    @application.get("/health", tags=["health"])
    def health(request: Request):
        data = request.app.state.recommender.data
        return {"status": "ok", "rules_version": data.rules.version, "catalog_version": data.catalog.version}

    return application


app = create_app()
