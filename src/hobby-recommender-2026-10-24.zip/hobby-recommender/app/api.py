from fastapi import APIRouter, HTTPException, Request

from app.models import RecommendationRequest, RecommendationResponse
from app.service import AnswerValidationError

router = APIRouter(prefix="/api/v1", tags=["recommendations"])


@router.post("/recommendations", response_model=RecommendationResponse)
def recommend(body: RecommendationRequest, request: Request):
    try:
        return request.app.state.recommender.recommend(body)
    except AnswerValidationError as exc:
        raise HTTPException(status_code=422, detail=exc.errors) from exc


@router.get("/catalog")
def catalog(request: Request):
    return request.app.state.recommender.data.catalog.model_dump()


@router.get("/questionnaire")
def questionnaire(request: Request):
    return request.app.state.recommender.data.questionnaire.model_dump()
