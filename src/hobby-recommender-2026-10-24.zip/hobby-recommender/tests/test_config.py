"""Reject invalid rule deployments before serving recommendation traffic."""
import json
import shutil
from pathlib import Path

import pytest

from app.config import DataBundle


DATA = Path(__file__).resolve().parents[1] / "app" / "data"


def changed_bundle(tmp_path, filename, mutate):
    directory = tmp_path / "data"
    shutil.copytree(DATA, directory)
    target = directory / filename
    payload = json.loads(target.read_text())
    mutate(payload)
    target.write_text(json.dumps(payload, ensure_ascii=False))
    return directory


def test_invalid_total_weight_fails_startup(tmp_path):
    directory = changed_bundle(
        tmp_path, "rules.json", lambda rules: rules["criteria"][0].update(weight=41)
    )
    with pytest.raises(ValueError, match="sum to 100"):
        DataBundle(directory)


def test_unknown_scoring_option_fails_startup(tmp_path):
    def mutate(rules):
        criterion = rules["criteria"][0]
        criterion["scores"]["원본 설문에 없는 선택지"] = next(iter(criterion["scores"].values()))

    directory = changed_bundle(tmp_path, "rules.json", mutate)
    with pytest.raises(ValueError, match="Unknown scoring option"):
        DataBundle(directory)


def test_unknown_activity_resource_fails_startup(tmp_path):
    def mutate(catalog):
        catalog["hobbies"][0]["activities"][0]["required_resources"].append("undefined_resource")

    directory = changed_bundle(tmp_path, "catalog.json", mutate)
    with pytest.raises(ValueError, match="Unknown resources"):
        DataBundle(directory)


def test_missing_hobby_score_fails_startup(tmp_path):
    def mutate(rules):
        next(iter(rules["criteria"][0]["scores"].values())).pop("reading")

    directory = changed_bundle(tmp_path, "rules.json", mutate)
    with pytest.raises(ValueError, match="Every scored option must define every hobby"):
        DataBundle(directory)
