"""Validate the complete versioned data bundle once, before accepting requests."""
import json
import math
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator

from app.models import StrictModel


class QuestionGroup(StrictModel):
    key: str
    code: str
    title: str
    kind: Literal["single", "multi"]
    options: list[str]
    exclusive: list[str] = Field(default_factory=list)
    max: int | None = None
    custom_option: str | None = None


class Questionnaire(StrictModel):
    version: str
    groups: list[QuestionGroup]


class Criterion(StrictModel):
    key: str
    weight: float = Field(gt=0)
    aggregation: Literal["max", "mean"]
    scores: dict[str, dict[str, float]]


class Rules(StrictModel):
    version: str
    criteria: list[Criterion]


class Activity(StrictModel):
    id: str
    title: str
    total_minutes: int = Field(ge=1)
    active_minutes: int = Field(ge=1)
    first_cost_krw: int = Field(ge=0)
    repeat_cost_krw: int = Field(ge=0)
    required_resources: list[str]
    exclusion_tags: list[str]
    checks: list[str]

    @model_validator(mode="after")
    def check_time(self):
        if self.active_minutes > self.total_minutes:
            raise ValueError("active_minutes cannot exceed total_minutes")
        return self


class Hobby(StrictModel):
    id: str
    name: str
    ui_key: str
    interest_option: str
    activities: list[Activity] = Field(min_length=1)


class Catalog(StrictModel):
    version: str
    resources: dict[str, str]
    hobbies: list[Hobby] = Field(min_length=1)


class DataBundle:
    def __init__(self, directory: Path):
        def read(filename):
            return json.loads((directory / filename).read_text(encoding="utf-8"))

        self.questionnaire = Questionnaire.model_validate(read("questionnaire.json"))
        self.rules = Rules.model_validate(read("rules.json"))
        self.catalog = Catalog.model_validate(read("catalog.json"))
        self.groups = {q.key: q for q in self.questionnaire.groups}
        self._validate_references()

    def _validate_references(self):
        hobby_ids = [h.id for h in self.catalog.hobbies]
        criteria_keys = [c.key for c in self.rules.criteria]
        activity_ids = [a.id for h in self.catalog.hobbies for a in h.activities]
        for label, values in [("hobby", hobby_ids), ("criterion", criteria_keys), ("activity", activity_ids)]:
            if len(values) != len(set(values)):
                raise ValueError(f"Duplicate {label} IDs")
        if len(self.groups) != len(self.questionnaire.groups):
            raise ValueError("Duplicate question keys")
        required_keys = {f"q{i:02d}" for i in range(1, 14)} - {"q09"} | {"q09Place", "q09Exclude"}
        if set(self.groups) != required_keys:
            raise ValueError("Questionnaire keys do not match the v1 request contract")
        if self.questionnaire.version != "onboarding-2026-10-13":
            raise ValueError("Questionnaire version requires a new request contract")
        if not math.isclose(sum(c.weight for c in self.rules.criteria), 100):
            raise ValueError("Criterion weights must sum to 100")
        for group in self.groups.values():
            if len(group.options) != len(set(group.options)) or not group.options:
                raise ValueError(f"Invalid options: {group.key}")
            if not set(group.exclusive) <= set(group.options):
                raise ValueError(f"Invalid exclusive options: {group.key}")
            if group.custom_option and group.custom_option not in group.options:
                raise ValueError(f"Invalid custom option: {group.key}")
            if group.max is not None and group.max < 1:
                raise ValueError("Selection max must be positive")
        for criterion in self.rules.criteria:
            if criterion.key not in self.groups:
                raise ValueError(f"Unknown scoring question: {criterion.key}")
            for option, scores in criterion.scores.items():
                if option not in self.groups[criterion.key].options:
                    raise ValueError(f"Unknown scoring option: {option}")
                if set(scores) != set(hobby_ids):
                    raise ValueError("Every scored option must define every hobby")
                if any(not math.isfinite(v) or not 0 <= v <= 1 for v in scores.values()):
                    raise ValueError("Fit must be finite and between 0 and 1")
        for hobby in self.catalog.hobbies:
            if hobby.interest_option not in self.groups["q02"].options:
                raise ValueError(f"Unknown interest option: {hobby.id}")
            for activity in hobby.activities:
                if not set(activity.required_resources) <= set(self.catalog.resources):
                    raise ValueError(f"Unknown resources: {activity.id}")
                allowed_tags = set(self.groups["q09Exclude"].options) - {"없음", "직접 입력"}
                if not set(activity.exclusion_tags) <= allowed_tags:
                    raise ValueError(f"Unknown exclusion tags: {activity.id}")
