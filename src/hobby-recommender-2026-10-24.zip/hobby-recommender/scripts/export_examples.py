"""Refresh documented examples and OpenAPI from the actual service, not mock scores.

Run from the project root: .venv/bin/python -m scripts.export_examples
"""
import json
from pathlib import Path

from fastapi.testclient import TestClient

from app.main import create_app


def main():
    root = Path(__file__).resolve().parents[1]
    request = json.loads((root / "examples/request.json").read_text(encoding="utf-8"))
    with TestClient(create_app()) as client:
        response = client.post("/api/v1/recommendations", json=request)
        response.raise_for_status()
        outputs = {"examples/response.json": response.json(), "docs/openapi.json": client.get("/openapi.json").json()}
    for file, value in outputs.items():
        (root / file).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("Wrote actual API response and OpenAPI schema.")


if __name__ == "__main__":
    main()
