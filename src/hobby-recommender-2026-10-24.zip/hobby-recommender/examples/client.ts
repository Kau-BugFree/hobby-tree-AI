/** Standalone fetch integration. Pass real user answers, never prototype initial values. */
export type QuestionKey =
  | "q01" | "q02" | "q03" | "q04" | "q05" | "q06" | "q07"
  | "q08" | "q09Place" | "q09Exclude" | "q10" | "q11" | "q12" | "q13";

export interface RecommendationRequest {
  schema_version?: "onboarding-2026-10-13";
  answers: Partial<Record<QuestionKey, string | string[] | null>>;
  custom_values?: {
    q04_amount_krw?: number;
    q05_amount_krw?: number;
    q06_minutes?: number;
    q02_other?: string;
    q09_exclude_text?: string;
  };
  resources?: Record<string, boolean>;
  monthly_committed_krw?: number;
  top_k?: number;
}

export interface Activity {
  activity_id: string;
  title: string;
  total_minutes: number;
  active_minutes: number;
  estimated_first_cost_krw: number;
  estimated_repeat_cost_krw: number;
  status: "eligible" | "needs_confirmation";
  confirmation_required: string[];
}

export interface RecommendationResponse {
  status: "recommended" | "browse" | "needs_review" | "no_match";
  schema_version: string;
  rules_version: string;
  catalog_version: string;
  recommendations: Array<{
    hobby_id: string;
    name: string;
    ui_key: string;
    rank: number;
    score: number;
    breakdown: Array<{
      question_key: string;
      weight: number;
      fit: number;
      points: number;
      answered: boolean;
      selected: string[];
    }>;
    reasons: string[];
    activities: Activity[];
  }>;
  excluded: Array<{ hobby_id: string; name: string; reasons: string[] }>;
  unsupported_interests: string[];
  notices: string[];
  follow_up_questions: string[];
  preferences: {
    selection_mode: string;
    recording_mode: string | null;
    burdens: string[];
    weekly_frequency: string | null;
  };
  coverage: { weighted_answer_coverage: number; answered_groups: number; total_groups: number };
}

export class RecommendationApiError extends Error {
  constructor(public readonly status: number, public readonly detail: unknown) {
    super(`Recommendation API returned ${status}`);
  }
}

export async function fetchRecommendations(
  baseUrl: string,
  payload: RecommendationRequest,
  options: { signal?: AbortSignal; timeoutMs?: number; token?: string } = {},
): Promise<RecommendationResponse> {
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (options.signal?.aborted) controller.abort();
  else options.signal?.addEventListener("abort", abort, { once: true });
  const timer = setTimeout(abort, options.timeoutMs ?? 8000);
  try {
    const response = await fetch(`${baseUrl.replace(/\/$/, "")}/api/v1/recommendations`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    const body: unknown = await response.json();
    if (!response.ok) throw new RecommendationApiError(response.status, body);
    // Keep this interface aligned with docs/openapi.json when updating API versions.
    return body as RecommendationResponse;
  } finally {
    clearTimeout(timer);
    options.signal?.removeEventListener("abort", abort);
  }
}

/** Card view model for the existing onboarding UI. Preserve pending checks in the UI. */
type CurrentAppHobbyKey = "요리" | "러닝" | "독서";

function currentAppKey(key: string): CurrentAppHobbyKey {
  if (key === "요리" || key === "러닝" || key === "독서") return key;
  throw new Error(`Add the new hobby to the app's card renderer: ${key}`);
}

export function toRecommendationCards(response: RecommendationResponse) {
  return response.recommendations.map((recommendation) => {
    const activity = recommendation.activities[0];
    return {
      hobby: currentAppKey(recommendation.ui_key), // 런닝 maps to the existing HobbyKey 러닝.
      name: recommendation.name,
      match: Math.round(recommendation.score), // Label as 적합도 점수, never probability/accuracy.
      why: recommendation.reasons.join(" · "),
      firstActivity: activity.title,
      activityId: activity.activity_id,
      needsConfirmation: activity.status === "needs_confirmation",
      confirmationRequired: activity.confirmation_required,
    };
  });
}
