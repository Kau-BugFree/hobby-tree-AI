from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


Money = Annotated[int, Field(ge=0, le=1_000_000_000)]
Text200 = Annotated[str, Field(min_length=1, max_length=200)]


class CustomValues(StrictModel):
    q04_amount_krw: Money | None = None
    q05_amount_krw: Money | None = None
    q06_minutes: Annotated[int, Field(ge=1, le=1440)] | None = None
    q02_other: Text200 | None = None
    q09_exclude_text: Annotated[str, Field(min_length=1, max_length=500)] | None = None


class RecommendationRequest(StrictModel):
    schema_version: Literal["onboarding-2026-10-13"] = "onboarding-2026-10-13"
    answers: dict[str, str | list[str] | None] = Field(default_factory=dict, max_length=14)
    custom_values: CustomValues = Field(default_factory=CustomValues)
    # These are explicit follow-up confirmations, never inferred from q08.
    resources: dict[str, bool] = Field(default_factory=dict, max_length=100)
    monthly_committed_krw: Money | None = None
    top_k: Annotated[int, Field(ge=1, le=10)] | None = None


class ScorePart(StrictModel):
    question_key: str
    weight: float
    fit: float
    points: float
    answered: bool
    selected: list[str]


class ActivityResult(StrictModel):
    activity_id: str
    title: str
    total_minutes: int
    active_minutes: int
    estimated_first_cost_krw: int
    estimated_repeat_cost_krw: int
    status: Literal["eligible", "needs_confirmation"]
    confirmation_required: list[str]


class Recommendation(StrictModel):
    hobby_id: str
    name: str
    ui_key: str
    rank: int
    score: float
    breakdown: list[ScorePart]
    reasons: list[str]
    activities: list[ActivityResult]


class ExcludedHobby(StrictModel):
    hobby_id: str
    name: str
    reasons: list[str]


class Preferences(StrictModel):
    selection_mode: str
    recording_mode: str | None
    burdens: list[str]
    weekly_frequency: str | None


class Coverage(StrictModel):
    weighted_answer_coverage: float
    answered_groups: int
    total_groups: int


class RecommendationResponse(StrictModel):
    status: Literal["recommended", "browse", "needs_review", "no_match"]
    schema_version: str
    rules_version: str
    catalog_version: str
    recommendations: list[Recommendation]
    excluded: list[ExcludedHobby]
    unsupported_interests: list[str]
    notices: list[str]
    follow_up_questions: list[str]
    preferences: Preferences
    coverage: Coverage
