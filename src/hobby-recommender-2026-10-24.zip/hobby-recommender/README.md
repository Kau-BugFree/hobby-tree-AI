# Hobbytree 규칙 기반 취미 추천 API

`onboarding.ts`의 실제 질문·선택지를 받아 **요리·런닝·독서**를 추천하는 FastAPI 서비스입니다. 활동의 예산·시간·필수 제외 조건을 먼저 검사한 다음, 남은 취미의 가중 점수를 계산합니다. 질문 정의·점수 규칙·활동 카탈로그가 분리되어 취미와 정책을 확장하기 쉽습니다.

- [입력·출력·선택지 전체 가중치·구동 설명 보고서](docs/report.html) — 브라우저에서 파일을 열면 됩니다. 외부 자원 없이 작동하고 인쇄/PDF 저장을 지원합니다.
- [실제 요청 예제](examples/request.json), [실제 계산 응답](examples/response.json), [앱 통신 예제](examples/client.ts), [OpenAPI 스냅샷](docs/openapi.json)
- 원본 `onboarding.ts`와 동기화된 프로젝트 참조 파일은 수정하지 않았습니다.

## 빠르게 실행

Python 3.11 이상을 사용합니다. 아래 명령은 이 README가 있는 `hobby-recommender` 폴더에서 실행합니다.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Windows의 가상 환경 활성화 명령은 `.venv\Scripts\activate`입니다. 실행 후 [API 문서](http://localhost:8000/docs)에서 요청을 직접 보내볼 수 있습니다.

```bash
curl -X POST http://localhost:8000/api/v1/recommendations \
  -H 'Content-Type: application/json' \
  --data-binary @examples/request.json
```

예제는 **독서 100점 → 요리 95.75점**을 반환합니다. 런닝은 ‘많은 신체 활동’ 제외 조건으로 빠집니다. 독서의 보유 책 활동은 `eligible`, 요리는 재료·작업 조건을 더 확인해야 하므로 `needs_confirmation`입니다. 점수는 만족 확률이나 검증된 정확도가 아닙니다.

```bash
pytest -q
python -m scripts.export_examples
```

첫 명령은 테스트를 실행하고, 두 번째는 현재 구현으로 `examples/response.json`과 `docs/openapi.json`을 다시 생성합니다. HTML 보고서의 표·계산 예제는 함께 제공된 버전의 정적 스냅샷이므로 데이터나 구현 변경 시 함께 갱신해야 합니다.

## API

| 메서드 | 경로 | 기능 |
| --- | --- | --- |
| GET | `/health` | 실행 상태와 데이터 버전 |
| GET | `/api/v1/questionnaire` | 질문·선택지·배타 선택·최대 선택 수 |
| GET | `/api/v1/catalog` | 지원 취미·활동·자원 ID |
| POST | `/api/v1/recommendations` | 답변 검증 및 추천 계산 |
| GET | `/docs` | 자동 생성 API 문서 |

### 입력

```json
{
  "schema_version": "onboarding-2026-10-13",
  "answers": {
    "q02": ["독서"],
    "q03": ["휴식·기분 전환"],
    "q04": "0원",
    "q05": "1만 원까지",
    "q06": "15분",
    "q08": ["읽을 책·전자책"],
    "q09Place": ["집"],
    "q09Exclude": ["없음"],
    "q10": "혼자"
  },
  "custom_values": {},
  "resources": {"owned_book": true},
  "monthly_committed_krw": 0,
  "top_k": 3
}
```

| 필드 | 계약 |
| --- | --- |
| `schema_version` | 기본값 `onboarding-2026-10-13`. 다른 버전은 422 |
| `answers` | 모든 키 선택 입력. 단일 선택은 문자열, 복수 선택은 문자열 배열. 미응답은 생략 또는 `null`, 복수 선택은 빈 배열도 가능 |
| `custom_values` | 직접 입력 선택에 해당하는 값. 선택 없이 값을 보내거나 선택 후 값을 빠뜨리면 422 |
| `resources` | 카탈로그 자원 ID에 대해 `true`: 실제 사용 가능 확인, `false`: 사용 불가 확인, 미전송: 미확인 |
| `monthly_committed_krw` | 이번 달 **모든 취미**에 이미 지출·예약한 금액. 0~1,000,000,000 정수. 미전송 가능 |
| `top_k` | 1~10 정수. 생략 시 Q11 한 개 제안이면 1, 나머지 3. 지원 취미는 현재 최대 3개 |

직접 입력 필드는 다음과 같습니다.

| 선택지 | 값 필드 | 범위 |
| --- | --- | --- |
| Q04 ‘직접 금액 입력’ | `custom_values.q04_amount_krw` | 0~1,000,000,000원 정수 |
| Q05 ‘직접 금액 입력’ | `custom_values.q05_amount_krw` | 0~1,000,000,000원 정수 |
| Q06 ‘직접 시간 입력’ | `custom_values.q06_minutes` | 1~1,440분 정수 |
| Q02 ‘다른 취미 직접 입력’ | `custom_values.q02_other` | 공백뿐이지 않은 1~200자 |
| Q09 제외 ‘직접 입력’ | `custom_values.q09_exclude_text` | 공백뿐이지 않은 1~500자 |

문자열 숫자, 불리언 금액, 잘못된 선택지·키, 중복 선택, 배타 선택 위반은 422입니다. Q03은 최대 2개입니다. Q02의 ‘3개까지 추천’은 원본에서 안내 문구이며 `max` 정의가 없어 입력을 3개로 제한하지 않습니다. 원본 선택지의 정확한 문구는 `/api/v1/questionnaire`를 기준으로 사용하세요.

`onboarding.ts`의 `initial`은 Figma 프로토타입의 초기 상태입니다. 실제로 사용자가 고른 값처럼 자동 제출하지 마세요. Q08에서 ‘주방 도구’를 골랐다고 구체적인 자원의 보유를 확정하지 않습니다.

### 출력

주요 최상위 필드:

- `status`: `recommended`, `browse`, `needs_review`, `no_match`
- `schema_version`, `rules_version`, `catalog_version`: 재현·분석을 위한 버전
- `recommendations`: 취미 ID·이름·화면 키·순위·점수·질문별 `breakdown`·이유·활동 후보
- `excluded`: 모든 활동이 제외된 취미와 이유. 단순 `top_k` 미선정은 제외 사유로 반환하지 않음
- `unsupported_interests`: 현재 지원하지 않는 관심사. 원문 반환만 하며 서버에는 저장하지 않음
- `notices`, `follow_up_questions`: 안내와 각 추천 취미의 첫 활동에 대한 추가 확인 질문
- `preferences`: 선택 방식·기록 방식·부담 요소·주간 빈도
- `coverage`: 점수 응답 충실도 및 전체 응답 그룹 수

각 활동의 `confirmation_required`에는 그 활동에 필요한 확인 사항 전체가 있습니다. 최상위 `follow_up_questions`는 추천 취미별 **첫 활동**의 확인 항목만 모은 값이므로 다른 활동으로 바꾸면 해당 활동의 목록을 읽어야 합니다.

`weighted_answer_coverage`는 점수표에 있는 선택지가 최소 하나 있는 질문들의 가중치 합(0~100)입니다. 예를 들어 Q02에서 커피만 선택하면 Q02의 가중치 40은 포함되지 않습니다. `answered_groups`는 비어 있지 않은 응답 그룹 수로 ‘아직 모르겠어요’도 포함합니다. Q09가 두 그룹이어서 `total_groups`는 14입니다. 충실도는 확률이나 정확도가 아닙니다.

| 상태 | 앱에서의 처리 |
| --- | --- |
| `recommended` | 후보 표시. 활동의 `eligible` / `needs_confirmation`을 함께 확인 |
| `browse` | Q01 시작 의사 없음 또는 Q11 직접 찾기. 순위 추천 없이 탐색 안내 |
| `needs_review` | 직접 입력 제외 조건의 의미를 확인해야 함. 추천 목록을 비워 반환 |
| `no_match` | 조건을 충족하는 등록 활동이 없음. 제외 이유를 설명하고 사용자에게 수정 기회 제공 |

`needs_confirmation`은 오류가 아닙니다. 카탈로그의 활동별 `checks`는 항상 확인 항목으로 반환하며, 이 API는 확인 완료를 저장하는 기능이 없습니다. 따라서 물품을 모두 `true`로 보내도 요리·런닝은 재료·시작 안내 등의 확인을 앱에서 별도로 진행해야 합니다. 원본 B01~B06의 전체 후속 절차를 구현한 API는 아닙니다.

## 추천 계산 정책

```text
점수(hobby) = Σ [질문 가중치 × 질문별 적합도]
```

| 질문 | 가중치 | 복수 선택 합성 |
| --- | ---: | --- |
| Q02 관심 취미 | 40 | 최댓값. 직접 선택한 지원 취미 1.0, 나머지 0.5 |
| Q03 목적 | 30 | 선택한 목적 적합도의 평균 |
| Q08 물품 | 10 | 최댓값. 소유 확정에는 사용하지 않음 |
| Q09 선호 장소 | 15 | 최댓값. 필수 장소 제한에는 사용하지 않음 |
| Q10 동행 선호 | 5 | 단일 선택의 적합도 |

전체 선택지의 적합도는 [rules.json](app/data/rules.json) 및 [HTML 보고서](docs/report.html)에 있습니다. 점수표에 없는 선택은 방향성 신호로 사용하지 않으며, 해당 질문에 유효한 점수 신호가 하나도 없으면 중립값 0.5입니다. 가중치를 다시 정규화하지 않아 미응답만 있는 경우 세 취미 모두 50점입니다.

점수는 내림차순, 동점은 `hobby_id` 오름차순입니다. 활동은 확인 완료 가능 상태(`eligible`) 우선 → 첫 비용 → 전체 시간 → 활동 ID 순으로 정렬합니다. Q11은 기본 후보 수와 탐색 흐름, Q12·Q13은 표시 선호에만 반영합니다. Q07은 계획 참고값으로 전달하며 월 4주 환산이나 의무 목표에 사용하지 않습니다.

### 예산·시간·제외 조건

- **Q04**: 첫 활동의 재료·물품·대여·시설·이동을 포함한 신규 지출 상한. ‘확인한 뒤 결정’과 ‘아직 모르겠어요’는 미정이며 0원이 아닙니다.
- **Q05**: 모든 취미에 걸친 이번 달 한도. `monthly_committed_krw`가 있으면 `max(0, 월 한도 - 사용·예약 금액)`과 첫 비용을 비교합니다. 없으면 월 전체 한도만 상한으로 검사하고 유료 활동에는 남은 금액 확인을 요청합니다.
- **Q06**: 준비·정리·이동·대기를 포함한 전체 시간으로 필터링합니다. 직접 활동 시간은 별도 표시합니다.
- **Q09 필수 제외**: 태그가 일치하는 활동을 제외합니다. 미응답은 ‘없음’으로 가정하지 않습니다. 자유 텍스트는 자동 해석하지 않고 `needs_review`로 반환합니다.
- **자원**: 필수 자원이 `false`면 활동을 제외하고, 미확인이면 확인을 요청합니다. 소유·대여·시설 가능 여부를 자동 추측하지 않습니다.

모든 활동이 제외된 취미만 추천 대상에서 빠집니다. 강한 관심이나 높은 목적 점수가 필수 제외를 덮어쓰지 않습니다. 예산 미정은 유료 활동에서 추가 확인을 요청하고, 시간 미정은 모든 활동에서 확인을 요청합니다.

**월간 계획 전체의 예산 충족을 보장하지 않습니다.** 각 후보를 처음 실행할 때의 필요조건만 검사합니다. 여러 취미를 함께 선택했을 때의 합산 비용·반복 횟수는 이후 계획 기능에서 계산해야 합니다. 반복 비용은 표시용으로 반환합니다.

## 앱에서 연결

기존 TypeScript 앱은 [examples/client.ts](examples/client.ts)의 `fetchRecommendations`를 연결하면 됩니다. 시간 초과·호출 취소·422 오류 처리와 결과 상태 타입, 기존 카드 변환 함수가 포함되어 있습니다. 앱의 초기 표시값과 실제 제출 답변을 구분하고, 반환된 `ui_key`로 기존 카드에 연결하세요. 서버 이름은 ‘런닝’, 기존 그래픽 키는 ‘러닝’입니다.

- 같은 컴퓨터: `http://localhost:8000`
- 실제 휴대폰: 개발 컴퓨터의 접속 가능한 LAN IP 또는 HTTPS 배포 URL. 휴대폰의 localhost는 휴대폰 자신입니다.
- Android 에뮬레이터: 환경에 맞는 호스트 연결 주소를 별도로 설정합니다.

HTTP 422이면 `detail`의 `loc`·`msg`를 해당 질문 옆에 표시하세요. HTTP 5xx와 네트워크 실패는 재시도 가능한 상태로 구분하세요. 결과 점수에 `%`를 붙이지 않고, 조건 미확인 상태를 활동 가능 확정처럼 표시하지 마세요.

## 환경 변수와 배포

`.env.example`은 설정 예제이며 로컬 실행에서 자동 로드되지 않습니다. 환경 변수로 직접 전달하거나 Docker의 `--env-file`을 사용합니다.

```bash
export CORS_ORIGINS='https://your-app.example.com'
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

기본 허용 출처는 `http://localhost:8081,http://localhost:19006`입니다. 실제 웹 앱 출처를 쉼표로 구분해 설정하세요. CORS는 브라우저의 교차 출처 정책이며 인증·권한을 대신하지 않습니다. 자격 증명 허용은 꺼져 있습니다.

```bash
docker build -t hobby-recommender .
docker run --rm -p 8000:8000 --env-file .env.example hobby-recommender
```

현재 서비스는 상태를 저장하지 않으므로 여러 인스턴스에서 동일한 설정으로 확장할 수 있습니다. 실행 중 규칙을 다시 읽지는 않으므로 JSON 변경은 배포 또는 재시작으로 반영합니다. 실제 공개 배포에는 HTTPS, 인증·호출 제한, 버전별 로그·관측을 앞단에 추가하세요. 이 프로젝트에는 실제 배포·사용자 DB·피드백 학습·비용 수집이 포함되지 않습니다.

## 파일 구조와 확장

```text
app/
  main.py                 FastAPI 생성, 시작 시 데이터 로드, CORS
  api.py                  HTTP 경로 및 오류 응답
  models.py               요청·응답 모델
  config.py               JSON 설정 모델과 시작 시 무결성 검사
  service.py              응답 검증, 활동 필터, 점수·결과 구성
  data/
    questionnaire.json    질문·선택지·검증 규칙
    rules.json            가중치·선택지별 적합도
    catalog.json          취미·활동·필수 자원·제외 태그
examples/                 실행 가능한 입력·출력·통신 예제
tests/                    정책·입력·API·설정 검증
scripts/export_examples.py
README.md
docs/report.html
docs/openapi.json
```

취미 추가 시:

1. `catalog.json`에 취미 ID, 화면 키, 관심 선택지와 활동을 추가합니다. 활동 시간·비용·자원·제외 태그를 검토합니다.
2. `rules.json`의 모든 점수표 항목에 새 취미 열을 추가합니다. 적합도 0~1과 가중치 합 100을 유지합니다.
3. 필요한 설문 선택지를 추가하고 설문 버전·앱 매핑을 함께 업데이트합니다. 현재 `schema_version` 요청 모델도 새 버전에 맞게 변경해야 합니다.
4. 새 취미를 표시할 앱의 그래픽·화면 키와 `examples/client.ts`의 지원 키 목록을 추가합니다.
5. 실제 사례와 경계조건을 테스트하고 규칙·카탈로그 버전을 올립니다. 예제·OpenAPI·HTML 보고서를 갱신합니다.

장기적으로는 선택지 문자열을 안정적인 `option_id`로 버전 전환하고, 지출·예약 원장과 계획 서비스를 분리하며, 버전별 노출·선택·완료·만족도 데이터를 수집해 가중치를 평가할 수 있습니다. 이 서비스는 자유 텍스트의 의미를 임의로 분류하지 않습니다.

## 검증 결과

이 제공본은 자동 테스트 58개 통과, TypeScript 엄격 타입 검사, 실제 HTTP 요청·응답 및 클라이언트 통신을 확인했습니다. Docker 실행 환경이 없어 컨테이너 이미지 빌드·실행은 검증하지 않았습니다.

## 한계와 참고

가중치는 초기 설계값으로 실제 사용자 만족도에 대한 학습·검증 결과가 아닙니다. 활동 비용과 시간은 설계·검증용 예시이므로 운영 가격·이동·재료 조건으로 교체해야 합니다. 0원 활동은 실제 자원 사용 가능·추가 지출 없음 확인이 전제입니다. 베이킹 관심은 요리로 연결되지만 현재 카탈로그에 베이킹 활동은 없습니다.

- [FastAPI: Bigger Applications](https://fastapi.tiangolo.com/tutorial/bigger-applications/)
- [FastAPI: CORS](https://fastapi.tiangolo.com/tutorial/cors/)
- [Pydantic: Models](https://docs.pydantic.dev/latest/concepts/models/)
