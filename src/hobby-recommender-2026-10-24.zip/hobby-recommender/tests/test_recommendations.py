"""Public API behavior: validation, explainable scoring and activity feasibility."""
import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import create_app


COOKING = "요리 (한식·중식·양식·일식·제과·제빵)"
DATA = Path(__file__).resolve().parents[1] / "app" / "data"


@pytest.fixture
def client():
    with TestClient(create_app()) as session:
        yield session


def recommend(client, answers=None, **kwargs):
    response = client.post(
        "/api/v1/recommendations", json={"answers": answers or {}, **kwargs}
    )
    assert response.status_code == 200, response.text
    return response.json()


def ranked_ids(result):
    return [item["hobby_id"] for item in result["recommendations"]]


def scores(result):
    return {item["hobby_id"]: item["score"] for item in result["recommendations"]}


def activity_ids(result):
    return {
        activity["activity_id"]
        for hobby in result["recommendations"]
        for activity in hobby["activities"]
    }


def test_empty_answers_are_neutral_and_ties_are_deterministic(client):
    result = recommend(client)
    assert result["status"] == "recommended"
    assert scores(result) == {"cooking": 50.0, "reading": 50.0, "running": 50.0}
    assert ranked_ids(result) == ["cooking", "reading", "running"]
    assert result["coverage"]["weighted_answer_coverage"] == 0
    assert result["coverage"]["answered_groups"] == 0
    assert ranked_ids(recommend(client)) == ranked_ids(result)


@pytest.mark.parametrize(
    ("interest", "hobby_id"),
    [(COOKING, "cooking"), ("러닝·걷기", "running"), ("독서", "reading")],
)
def test_explicit_interest_ranks_the_matching_hobby_first(client, interest, hobby_id):
    result = recommend(client, {"q02": [interest]})
    assert ranked_ids(result)[0] == hobby_id
    assert scores(result)[hobby_id] == 70.0
    assert all(
        score == 50.0 for hobby, score in scores(result).items() if hobby != hobby_id
    )


@pytest.mark.parametrize(
    "answers",
    [
        {"q03": ["휴식·기분 전환", "건강·체력", "실력 향상·성취감"]},
        {"q02": ["독서", "독서"]},
        {"q02": ["독서", "아직 모르겠어요"]},
        {"q09Exclude": ["없음", "야외"]},
        {"q08": ["해당 없음", "확인이 필요해요"]},
        {"q99": "독서"},
        {"q02": ["목록에 없는 선택지"]},
        {"q10": ["혼자"]},
        {"q02": "독서"},
    ],
)
def test_invalid_answer_shapes_and_constraints_are_rejected(client, answers):
    response = client.post("/api/v1/recommendations", json={"answers": answers})
    assert response.status_code == 422, response.text


def test_q02_three_is_guidance_not_an_enforced_maximum(client):
    result = recommend(client, {"q02": ["커피", COOKING, "독서", "러닝·걷기"]})
    assert len(result["recommendations"]) == 3


@pytest.mark.parametrize(
    "payload",
    [
        {"answers": {"q04": "직접 금액 입력"}},
        {"answers": {"q05": "직접 금액 입력"}},
        {"answers": {"q06": "직접 시간 입력"}},
        {"answers": {"q02": ["다른 취미 직접 입력"]}},
        {"answers": {"q09Exclude": ["직접 입력"]}},
        {"custom_values": {"q04_amount_krw": 1000}},
        {"custom_values": {"q05_amount_krw": 1000}},
        {"custom_values": {"q06_minutes": 15}},
        {"custom_values": {"q02_other": "수채화"}},
        {"custom_values": {"q09_exclude_text": "특정 재료 제외"}},
    ],
)
def test_custom_values_require_the_corresponding_selection(client, payload):
    response = client.post("/api/v1/recommendations", json=payload)
    assert response.status_code == 422, response.text


def test_zero_money_is_a_valid_explicit_budget(client):
    result = recommend(
        client,
        {"q04": "직접 금액 입력", "q05": "직접 금액 입력"},
        custom_values={"q04_amount_krw": 0, "q05_amount_krw": 0},
        monthly_committed_krw=0,
    )
    assert result["recommendations"]
    assert all(
        activity["estimated_first_cost_krw"] == 0
        for hobby in result["recommendations"]
        for activity in hobby["activities"]
    )


@pytest.mark.parametrize("value", [True, "1000", -1, 1.5])
@pytest.mark.parametrize("field", ["q04_amount_krw", "q05_amount_krw"])
def test_money_does_not_coerce_invalid_values(client, field, value):
    key = field[:3]
    response = client.post(
        "/api/v1/recommendations",
        json={"answers": {key: "직접 금액 입력"}, "custom_values": {field: value}},
    )
    assert response.status_code == 422, response.text


@pytest.mark.parametrize("value", [0, True, "10", -1])
def test_custom_time_requires_a_positive_integer(client, value):
    response = client.post(
        "/api/v1/recommendations",
        json={
            "answers": {"q06": "직접 시간 입력"},
            "custom_values": {"q06_minutes": value},
        },
    )
    assert response.status_code == 422, response.text


def test_unsupported_interest_is_acknowledged_without_becoming_a_hobby(client):
    result = recommend(client, {"q02": ["커피"]})
    assert "커피" in result["unsupported_interests"]
    assert result["notices"]
    assert set(ranked_ids(result)) == {"cooking", "running", "reading"}
    assert set(scores(result).values()) == {50.0}


@pytest.mark.parametrize(
    "answers",
    [
        {"q01": "지금은 취미를 시작할 생각이 없어요"},
        {"q11": "안내 없이 직접 찾기"},
    ],
)
def test_browse_preference_is_respected(client, answers):
    result = recommend(client, answers)
    assert result["status"] == "browse"
    assert result["recommendations"] == []


def test_single_suggestion_preference_and_explicit_limit(client):
    answers = {"q11": "한 개를 제안받기", "q02": ["독서"]}
    assert ranked_ids(recommend(client, answers)) == ["reading"]
    assert len(recommend(client, answers, top_k=3)["recommendations"]) == 3


@pytest.mark.parametrize(
    "excluded", [["야외", "외부 시설"], ["많은 신체 활동"]]
)
def test_strict_exclusions_remove_all_incompatible_running_activities(client, excluded):
    result = recommend(client, {"q02": ["러닝·걷기"], "q09Exclude": excluded})
    assert "running" not in ranked_ids(result)
    assert "running" in [hobby["hobby_id"] for hobby in result["excluded"]]


def test_fire_exclusion_preserves_no_fire_cooking_options(client):
    result = recommend(client, {"q09Exclude": ["화기 사용"]})
    assert "cooking" in ranked_ids(result)
    assert "cooking-warm-soup" not in activity_ids(result)
    assert "cooking-pantry-dressing" in activity_ids(result)


def test_no_available_resources_returns_no_match(client):
    resource_keys = json.loads((DATA / "catalog.json").read_text())["resources"]
    result = recommend(client, resources={key: False for key in resource_keys})
    assert result["status"] == "no_match"
    assert result["recommendations"] == []


def test_insufficient_total_time_returns_no_match(client):
    result = recommend(
        client, {"q06": "직접 시간 입력"}, custom_values={"q06_minutes": 1}
    )
    assert result["status"] == "no_match"
    assert result["recommendations"] == []


def test_missing_resources_and_broad_q08_selection_are_not_confirmation(client):
    result = recommend(client, {"q08": ["읽을 책·전자책", "주방 도구", "운동화·운동복"]})
    activities = [a for hobby in result["recommendations"] for a in hobby["activities"]]
    assert activities
    assert all(a["status"] == "needs_confirmation" for a in activities)
    assert all(a["confirmation_required"] for a in activities)


def test_explicit_resource_and_constraint_confirmation_can_make_activity_eligible(client):
    result = recommend(
        client,
        {
            "q04": "0원", "q05": "0원", "q06": "10분",
            "q07": "주 1회", "q09Exclude": ["없음"],
        },
        resources={"owned_book": True},
        monthly_committed_krw=0,
    )
    reading = next(h for h in result["recommendations"] if h["hobby_id"] == "reading")
    owned = next(a for a in reading["activities"] if a["activity_id"] == "reading-owned-10")
    assert owned["status"] == "eligible"
    assert owned["confirmation_required"] == []


def test_monthly_commitments_reduce_the_shared_budget_for_every_hobby(client):
    answers = {"q04": "1만 원까지", "q05": "3만 원까지", "q07": "주 1회"}
    uncommitted = recommend(client, answers, monthly_committed_krw=0)
    committed = recommend(client, answers, monthly_committed_krw=29000)
    assert "cooking-buy-dressing" in activity_ids(uncommitted)
    assert "running-indoor-40" in activity_ids(uncommitted)
    assert "cooking-buy-dressing" not in activity_ids(committed)
    assert "running-indoor-40" not in activity_ids(committed)
    assert "reading-owned-10" in activity_ids(committed)


def test_deferred_budget_is_unknown_rather_than_zero(client):
    deferred = recommend(client, {"q04": "나와 맞는지 확인한 뒤 결정"})
    zero = recommend(client, {"q04": "0원"})
    assert "cooking-buy-dressing" in activity_ids(deferred)
    assert "cooking-buy-dressing" not in activity_ids(zero)


def test_freeform_exclusion_requires_review_without_recommendations(client):
    result = recommend(
        client, {"q09Exclude": ["직접 입력"]},
        custom_values={"q09_exclude_text": "특정 재료를 제외해야 해요"},
    )
    assert result["status"] == "needs_review"
    assert result["recommendations"] == []
    assert result["follow_up_questions"]


def test_recording_and_burden_preferences_do_not_change_hobby_scores(client):
    baseline = recommend(client, {"q02": ["독서"]})
    preferences = recommend(
        client,
        {"q02": ["독서"], "q12": "기록하지 않기", "q13": ["여러 항목 기록", "기한 목표"]},
    )
    assert scores(preferences) == scores(baseline)
    assert preferences["preferences"]["recording_mode"] == "기록하지 않기"
    assert preferences["preferences"]["burdens"] == ["여러 항목 기록", "기한 목표"]


def test_score_breakdown_adds_up_and_goal_selections_are_averaged(client):
    result = recommend(client, {"q03": ["건강·체력", "창작·자기표현"]})
    for hobby in result["recommendations"]:
        assert sum(part["points"] for part in hobby["breakdown"]) == pytest.approx(hobby["score"], abs=.02)
        goal = next(part for part in hobby["breakdown"] if part["question_key"] == "q03")
        if hobby["hobby_id"] == "running":
            assert goal["fit"] == pytest.approx(.7)
            assert goal["points"] == pytest.approx(21.0)


def test_api_discovery_endpoints(client):
    assert client.get("/health").status_code == 200
    catalog = client.get("/api/v1/catalog")
    questionnaire = client.get("/api/v1/questionnaire")
    assert catalog.status_code == questionnaire.status_code == 200
    assert len(catalog.json()["hobbies"]) == 3
    assert len(questionnaire.json()["groups"]) == 14
    assert client.get("/docs").status_code == 200
    schema = client.get("/openapi.json").json()
    assert "/api/v1/recommendations" in schema["paths"]
